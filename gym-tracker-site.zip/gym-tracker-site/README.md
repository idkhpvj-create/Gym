# Training log

A standalone version of your gym progress tracker, ready to deploy as its own website.

## What changed from the Claude artifact

The app logic is identical to the version in Claude. The only difference is
`src/storageShim.js`, which replaces Claude's `window.storage` API with the
browser's built-in `localStorage`. That means:

- Your data is saved in the browser you use, on the device you use it on.
- It will **not** sync across devices or browsers (no login system here).
- Clearing your browser's site data for this URL will erase your history.

If you later want data that follows you across devices, the app would need a
real backend (e.g. Supabase, Firebase, or your own API) instead of
`localStorage` — happy to help set that up when you're ready.

## Run it locally

You'll need [Node.js](https://nodejs.org) installed (version 18 or later).

```bash
npm install
npm run dev
```

This starts a local server (usually at `http://localhost:5173`) where you can
try the site before deploying it.

## Deploy it for free

The easiest options are **Vercel** or **Netlify** — both offer free hosting
for projects like this and deploy straight from a GitHub repo.

### Option A: Vercel

1. Push this folder to a new GitHub repository.
2. Go to [vercel.com](https://vercel.com), sign in, and click "New Project."
3. Import your repository. Vercel auto-detects Vite — leave the defaults.
4. Click "Deploy." You'll get a live URL like `your-project.vercel.app`.

### Option B: Netlify

1. Push this folder to a new GitHub repository.
2. Go to [netlify.com](https://netlify.com), sign in, and click "Add new site" → "Import an existing project."
3. Connect your repo. Set build command to `npm run build` and publish directory to `dist`.
4. Click "Deploy site."

### Option C: No GitHub, drag-and-drop

1. Run `npm run build` locally — this creates a `dist/` folder.
2. Go to [app.netlify.com/drop](https://app.netlify.com/drop) and drag the `dist` folder in.
3. Netlify gives you a live link immediately.

## Custom domain

Once deployed, both Vercel and Netlify let you attach your own domain name
(e.g. `mytraininglog.com`) for free under Site settings → Domains.
